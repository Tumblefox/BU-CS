/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CPUSIM;

/**
 * The output chart containing the results of the simulation
 * @author A'Jee Sieka
 */
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;

public class OutputChart extends Application {
    private long[] endTimes;
    private long startTime;
    private RunSimulation sim;
    private Button button;
 
    @Override public void start(Stage stage) {
        runProcess(stage);
    }
    
    public void runProcess(Stage stage) {
        sim = new RunSimulation();
        startTime = sim.getStart();
        endTimes = sim.getTimes();
      
        stage.setTitle("Results");
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        final BarChart<String,Number> bc = new BarChart<String,Number>(xAxis,yAxis);
        bc.setTitle("SRB Time Analysis");
        bc.setMaxSize(600, 450);
        xAxis.setLabel("SRB");       
        yAxis.setLabel("Completion Time");
 
        XYChart.Series series1 = new XYChart.Series();
        series1.setName("Times");
        
        for(int i = endTimes.length - 1; i > -1; i--) {
          System.out.println("Adding time " + i + " (" + (endTimes[i] - startTime) + ")");
          series1.getData().add(new XYChart.Data(""+i, Math.abs(endTimes[i] - startTime)));
        }       
        button = new Button("Run Simulation Again");
        button.setOnAction(value -> {runProcess(stage);});
        
        StackPane layout = new StackPane();
        layout.setPadding(new Insets(50,50,50,50));
        layout.getChildren().addAll(bc,button);
        StackPane.setAlignment(button, Pos.BOTTOM_CENTER);
        Scene scene  = new Scene(layout,800,600);
        bc.getData().addAll(series1);
        stage.setScene(scene);
        stage.show();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
