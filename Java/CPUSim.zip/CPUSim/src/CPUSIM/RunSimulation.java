/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CPUSIM;

/**
 * Runs InteractionObjects, collecting the start time and end times
 * @author A'Jee Sieka
 */
public class RunSimulation {
  private long[] endTimes;
  private long startTime;
  
  public RunSimulation() {
    InteractionObjects objects = new InteractionObjects();
    startTime = System.nanoTime();
    System.out.println("Start Time: " + startTime);
    endTimes = objects.run();
    for (int i = 0; i < endTimes.length; i++)
      System.out.println("Time " + i + ": " + endTimes[i]);
    
    System.out.println("Time elapsed: " + ((System.nanoTime() - startTime) / 1000000) + " milliseconds");
  }
  
  public long[] getTimes() {
    return endTimes;
  }
  
  public long getStart() {
    return startTime;
  }
}
