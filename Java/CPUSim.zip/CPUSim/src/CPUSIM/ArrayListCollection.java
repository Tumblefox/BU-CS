/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CPUSIM;

/**
 * A collection of ArrayLists, their critical sections, and their IDs, all stored in separate vectors
 * @author A'Jee Sieka
 */
import java.util.Vector;
import java.util.Random;
import java.util.ArrayList;

public class ArrayListCollection {
  private Vector<ArrayList> list;
  private int capacity;
  private Vector<String> id;
  private Vector<Double> criticalSections;
  private Random r;
  
  /**
   * Constructor
   * @param capacity The initial number of ArrayLists to be stored
   */
  public ArrayListCollection(int capacity) {
    list = new Vector(capacity);
    this.capacity = capacity;
    r = new Random();
    id = new Vector(capacity);
    criticalSections = new Vector(capacity);
  }
  /**
   * Creates and populates each ArrayList in the collection, and generates IDs and critical sections
   * @param numOfElem The number of elements for each ArrayList
   */
  public void fill(int numOfElem) {
    for (int i = 0; i < capacity; i++) {
      list.add(new ArrayList(numOfElem));
      id.add(listID(i));
      criticalSections.add(1 + ((r.nextInt(22) + 67) / 100.0));
      for (int j = 0; j < numOfElem - 1; j++) {
        if (r.nextInt(2) == 0) {//0=String
          list.get(i).add(randomString());
        }
        else //1=Int
          list.get(i).add(j, r.nextInt(1000));
      }
    }
  }
  /**
   * Creates an ID given the number of the ArrayList
   * @param i The number of the ArrayList
   * @return A generated ID string
   */
  private String listID(int i) {
    return "SRB" + i;
  }
  /**
   * Creates a random string with 1-10 random ASCII characters
   * @return A string with random characters
   */
  private String randomString() {
    int length = r.nextInt(9) + 1;
    String s = "";
    
    for (int i = 0; i < length; i++)
      s +=(char) (r.nextInt(96) + 32);
   return s; 
  }
  /**
   * Gets the index of a random ArrayList in the collection
   * @return ArrayList index in the collection
   */
  public int randomListIndex() {
      if((list.size() - 1) > 0)
          return r.nextInt(list.size() - 1);
      else
          return 0;
  }
  /**
   * Gets the ID of a specified ArrayList
   * @param i The index of the desired ArrayList
   * @return The desired ID string
   */
  public String getListID(int i) {
    return id.get(i);
  }
  /**
   * Indicates when the collection has no more ArrayLists
   * @return True if empty, False if not
   */
  public boolean isCollectionEmpty() {
    return list.isEmpty();
  }
  /**
   * Indicates when an ArrayList in the collection is empty
   * @param i The desired ArrayList in the collection
   * @return True if empty, False if not
   */
  public boolean isListEmpty(int i) {
    return list.get(i).isEmpty();
  }
  /**
   * Adds the given object to the specified ArrayList
   * @param listIndex The index of the desired ArrayList
   * @param o The object to be added
   */
  public void addToList(int listIndex, Object o) {
    list.get(listIndex).add(o);
  }
  /**
   * Removes a given element from the specified ArrayList
   * @param listIndex The index of the specified ArrayList
   * @param i The index of the specified element in the ArrayList
   * @return The object removed from the ArrayList
   */
  public Object removeFromList(int listIndex, int i) {
    return list.get(listIndex).remove(i);
  }
  /**
   * Removes the last element from the specified ArrayList
   * @param listIndex The index of the specified ArrayList
   * @return The object removed from the ArrayList
   */
  public Object removeFromList(int listIndex) {
    int end = list.get(listIndex).size() - 1;
    return list.get(listIndex).remove(end);
  }
  /**
   * Removes an ArrayList from the collection
   * @param i The specified ArrayList to be removed
   */
  public void removeList(int i) {
    list.remove(i);
    criticalSections.remove(i);
    id.remove(i);
  }
  /**
   * Indicates Whether a the specified ArrayList has reached its critical section (increased by a certain percentage)
   * @param i The index of the specified ArrayList
   * @param iniCapacity The initial capacity of the specified ArrayList
   * @return True if critical section is reached, False if not
   */
  public boolean reachedCritical(int i, int iniCapacity) {
    //System.out.println("List " + i + " critical section: " + criticalSections[i]);
    double maxCap = iniCapacity * criticalSections.get(i);
    
    if (list.get(i).size() >= maxCap) {
      //System.out.println("List " + i + " has reached its critical section");
      return true;
    }
    else {
      return false;
    }
  }
  /**
   * Finds an ArrayList that has not reached its critical section
   * @param iniCapacity The initial capacity of all ArrayLists
   * @return The index of a suitable ArrayList, -1 if none exist
   */
  public int findNonCritical(int iniCapacity) {
      int index = -1;
      int i = 0;
      boolean found = false;
      while (i < list.size() && !found) {
          if(!reachedCritical(i, iniCapacity)) {
              index = i;
              found = true;
          }
          i++;
      }
      return index;
  }
  /**
   * Finds out how many ArrayLists are in the collection
   * @return Number of remaining ArrayLists
   */
  public int remainingLists() {
    return list.size();
  }
  /**
   * Finds the number of elements in the specified ArrayList
   * @param listIndex The index of the desired ArrayList
   * @return The Number of remaining elements in the ArrayList
   */
  public int remainingInList(int listIndex) {
    return list.get(listIndex).size();
  }
}
