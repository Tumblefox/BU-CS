/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CPUSIM;

/**
 * Simulated interactions between an SRB, Producer, and Consumer
 * @author A'Jee Sieka
 */
import java.util.Random;

public class InteractionObjects {
  private ArrayListCollection srb; //Source Request Buffer; 10 ArrayLists, each with 100 random strings and integers
  private ArrayListCollection consumers; //ALUs (Consumers); 8, each with 100 random strings and integers and a unique ID
  private ArrayListCollection producers; // 50, each with 100 random strings and integers and a unique ID
  
  private Random r;
  private long[] emptyTime; //time to empty each SRB request
  
  public InteractionObjects() {
    r = new Random();
    emptyTime = new long[10];
    
    srb = new ArrayListCollection(10);
    srb.fill(100);
    consumers = new ArrayListCollection(8);
    consumers.fill(100);
    producers = new ArrayListCollection(50);
    producers.fill(50);
  }
  
  public boolean srbToProducer() {
      System.out.println(srb.remainingLists() + " left in srb");
      if(!srb.isCollectionEmpty()) {
          //int i = srb.remainingLists() - 1;
          int i = srb.randomListIndex();
          if(!srb.isListEmpty(i)) {
              Object o = srb.removeFromList(i);
              int j = producers.findNonCritical(50);
              if (j != -1)
                producers.addToList(j, o);
          }
          else {
              String s = srb.getListID(i);
              int list = Integer.parseInt(s.substring(3, s.length()));
              emptyTime[list] = System.nanoTime();
              srb.removeList(i);
              System.out.println("SRB" + i + " has been depleted");
          }
          return true;
      }
      else {
          return false;
      }
  }
  
  public void producerToConsumer() {
    int list = r.nextInt(producers.remainingLists());
    Object element = producers.removeFromList(list, r.nextInt(producers.remainingInList(list)));
    consumers.addToList(r.nextInt(7), element);
    System.out.println("Producer has passed a job to Consumer (" + element + ")");
  }
  
  public void consume() {
    consumers.removeFromList(r.nextInt(7));
    System.out.println("Consumer has finished a job");
  }
  
  public long[] run() {
    boolean notDepleted = true;
    
    while(notDepleted) {
      int selection = r.nextInt(3);
      if (selection == 0) {
        producerToConsumer();
      }
      if (selection == 1) {
        consume();
      }
      if (selection == 2) {
        notDepleted = srbToProducer();
      }
    }
    
    System.out.println("SRB collection is empty!");
    return emptyTime;
  }
}
